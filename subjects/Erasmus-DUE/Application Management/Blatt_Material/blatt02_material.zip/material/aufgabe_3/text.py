import random

def text_1():
    return "Super awesome text generation 2.0"


def text_2():
    return f'Some random number {random.randint(0, 9999)}'
