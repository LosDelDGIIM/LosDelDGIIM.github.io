from text import text_1

def main():
    print(text_1())
    print("This is an super awesome real time messaging app.")


if __name__ == '__main__':
    main()
