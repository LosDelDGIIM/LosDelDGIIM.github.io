def false():
    return False


def true():
    return True
