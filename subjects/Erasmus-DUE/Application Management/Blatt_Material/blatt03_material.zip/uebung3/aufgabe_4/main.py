from text import text_1, text_2

def main():
    print(text_1(), '\n', text_2())
    print("This is an super awesome real time messaging app. Or maybe its just printing something.")


if __name__ == '__main__':
    main()
