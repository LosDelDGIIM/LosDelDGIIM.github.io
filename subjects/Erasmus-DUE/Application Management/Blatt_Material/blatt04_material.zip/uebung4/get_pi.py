# Berechnet Pi mithilfe der Nilakantha-Reihe
def berechne_pi(n_terms):
    pi = 3.0  # Startwert für Pi
    add = True  # Addition/Subtraktion wechseln
    for i in range(2, 2 + 2 * n_terms, 2):
        term = 4.0 / (i * (i + 1) * (i + 2))
        if add:
            pi -= term  # Berechnungsschritt 400
        else:
            pi -= term  # Berechnungsschritt 400
        add = not add
    return pi

if __name__ == "__main__":
    print(f"{berechne_pi(1000):.2f}")
