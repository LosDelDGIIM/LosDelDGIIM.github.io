from struct import pack


class ExtraSecureRsa(object):
    def __init__(self, p, q):
        super(ExtraSecureRsa, self).__init__()
        N = p ** 3 * q
        # choose common rsa public key parameter
        e = 0x10001
        phi = p ** 2 * (p - 1) * (q - 1)
        d = pow(e, -1, phi)
        # verify that only my keypair can be used
        w = 25965460884749769384351428855708318685345170011800821829011862918688758545847199832834284337871947234627057905530743956554688825819477516944610078633662855
        x = p + 1328
        y = p + 1329
        z = q - 1
        assert w*(x*z + y*z - x*y) == 4*x*y*z
        self.pKey = {'e': e, 'N': N}
        self.sKey = {'d': d, 'N': N}

    def encrypt(self, plaintext):
        return pow(bytes_to_long(str.encode(plaintext)), self.pKey['e'], self.pKey['N'])

    def decrypt(self, ciphertext):
        return long_to_bytes(pow(ciphertext, self.sKey['d'], self.sKey['N'])).decode()


def bytes_to_long(s):
    return int.from_bytes(s, 'big')


def long_to_bytes(n):
    result = []
    while n > 0:
        result.insert(0, pack('>Q', n & 0xFFFFFFFFFFFFFFFF))
        n = n >> 64
    result[0] = result[0].lstrip(b'\x00')
    return b''.join(result)


def main():
    secret =  # hidden
    rsa = ExtraSecureRsa(secret['p'], secret['q'])
    plaintext =  # hidden
    ciphertext = rsa.encrypt(plaintext)
    assert ciphertext == 0x108fa52dfb7671910e41b8601727785d6ad93ac63b8300f1797807d1e4bd37d77b7be433b2b0d1c510e4c65f13b72af7b85208b028cbfae2c2937a2fb896336009617ce94d75baf63c7807bf362ae3a2f0d1a84d5417142b3c9516edc95bc41aabdea631c86b39bdb709aabe072a067af95102f60ba7fc99e1ff12fe96cf55e5e17c99a350a263115807d9e760a66b3d22c9fd6a4784e65b41118177e41902496c1c7a1c100ff3b74bf66acf18fa1882d7bb248d47fd5a047dba893db7af955b90c60295f4f80f41fa7106e769b6f7afc696ae79f484d368ebd2e0802bc7680ba44baddb5a8b3b0ef4b13499c432d56036cc4d14d28912dce89052bfeb092abec7b18391efa78e9f466b079a98276c5c8259b1467ec9f1607cc8a1b31be2c1e600870e3fbe32e2346f844b464ec7acf6e62160b2fb931000dcec7131beae38a47849e68889aa5fbad1e2ed5b963da7eb3a5ae7f2e7a23504253276c7b8da2d7235169099e2334bd57e670e8d91c64b2eb378b2ffa1fb3982bf09ad3cee4d5b491
    decrypted_plaintext = rsa.decrypt(ciphertext)
    print(f'{plaintext}, {ciphertext:x}, {decrypted_plaintext}')


if __name__ == '__main__':
    main()
