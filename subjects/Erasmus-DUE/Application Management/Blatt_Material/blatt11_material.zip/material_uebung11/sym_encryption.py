def enc(text, key):
    text = str.encode(text)
    key = str.encode(key)
    encrypted = []
    for i in range(int(round(len(text) / 4))):
        tmp = text[i * 4: (i + 1) * 4]
        for p in range(len(tmp)):
            encrypted.append(int((tmp[p] + i) ^ key[p]))
    return encrypted


def dec(text, key):
    key = str.encode(key)
    encrypted = []
    for i in range(int(round(len(text) / 4))):
        tmp = text[i * 4: (i + 1) * 4]
        for p in range(len(tmp)):
            encrypted.append(int((tmp[p] ^ key[p]) - i))
    return bytes(encrypted)


def main():
    plaintext =  # hidden
    key =  # hidden

    ciphertext = enc(plaintext, key)
    assert ciphertext == [7, 29, 25, 64, 114, 31, 4, 18, 48, 87, 0, 66, 36, 86, 6,
                          65, 119, 2, 25, 84, 41, 2, 26, 22, 56, 1, 25, 75, 211, 2, 11, 67, 36, 3, 70]

    decrypted_plaintext = dec(ciphertext, key).decode()

    print(f'{plaintext}, {ciphertext}, {decrypted_plaintext}')


if __name__ == '__main__':
    main()
