#!/usr/bin/python3

from typing import List

# PASSCODE = [getrandombits(8) for _ in range(4)]
PASSCODE = [64, 63, 121, 119]


def validate(data: List[int]):
    if len(data) != 4:
        return

    if PASSCODE[0] == data[0]:
        if PASSCODE[1] % 3 == data[1]:
            if PASSCODE[2] * 2 + 4 == data[2]:
                if PASSCODE[3] + PASSCODE[0] == data[3]:
                    raise RuntimeError("passcode match")
    return
