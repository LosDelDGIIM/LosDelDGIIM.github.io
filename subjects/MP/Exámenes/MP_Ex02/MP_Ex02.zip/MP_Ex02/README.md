# Metodología de la Programación. Examen II (Prácticas).

- **Asignatura:** Metodología de la Programación.
- **Curso Académico:** 2020-21.
- **Grado:** Doble Grado en Ingeniería Informática y Matemáticas.
<!-- - **Grupo:** A. -->
<!-- - **Profesor:** Andrés Cano Utrera. -->
- **Descripción:** Examen de Prácticas (a ordenador).
<!-- - **Fecha:** 9 de mayo de 2023. -->
<!-- - **Duración:** -->