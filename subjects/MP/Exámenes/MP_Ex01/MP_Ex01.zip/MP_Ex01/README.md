# Metodología de la Programación. Examen I (Prácticas).

- **Asignatura:** Metodología de la Programación.
- **Curso Académico:** 2022-23.
- **Grado:** Doble Grado en Ingeniería Informática y Matemáticas.
- **Grupo:** A.
- **Profesor:** Andrés Cano Utrera.
- **Descripción:** Examen de Prácticas (a ordenador).
- **Fecha:** 9 de mayo de 2023.
<!-- - **Duración:** -->