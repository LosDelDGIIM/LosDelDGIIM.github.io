# Metodología de la Programación. Examen III (Prácticas).

**Autor:** victryx
***

- **Asignatura:** Metodología de la Programación.
- **Curso Académico:** 2024-25
- **Grado:** Ingeniería Informática.
<!-- - **Grupo:** A. -->
- **Profesor:** David Pelta Mochcovsky
- **Descripción:** Examen de Prácticas (a ordenador).
<!-- - **Fecha:** 9 de mayo de 2023. -->
<!-- - **Duración:** -->

- Compilar con `cd examen_resuelto`, `make`
- Ejecutar con `make run`
- La nota obtenida fue de 10 sobre 10, en principio la resolución es correcta
- Para descargar, está disponible el archivo [`MP_Ex03.zip`](./MP_Ex03.zip).
