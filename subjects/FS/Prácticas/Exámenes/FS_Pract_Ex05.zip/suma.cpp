#include <stdlib.h>
#include <stdio.h>
#include "funciones.h"


/*
 Suma de dos numeros
 
*/

int suma (int x, int y)
{
   int tmp;

   tmp = x + y; 

   return tmp;
}
