int suma (int x, int y);
int resta (int x, int y);