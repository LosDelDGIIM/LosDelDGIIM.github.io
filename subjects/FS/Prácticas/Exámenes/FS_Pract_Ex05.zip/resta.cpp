#include <stdlib.h>
#include <stdio.h>
#include "funciones.h"


/*
 Resta de dos numeros
 
*/

int resta (int x, int y)
{
   int tmp;

   tmp = x - y; 

   return tmp;
}
